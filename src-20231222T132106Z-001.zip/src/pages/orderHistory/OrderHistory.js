import styles from "./OrderHistory.module.css";

const OrderHistory = () => {
  return <div>
    <h1>Under Construction...</h1>
  </div>;
};
export default OrderHistory;
